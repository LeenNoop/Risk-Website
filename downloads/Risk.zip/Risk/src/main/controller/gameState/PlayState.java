package main.controller.gameState;

/**
 *
 * @author Ben Owen
 *
 */
public class PlayState extends GameState{

	public PlayState(GameStateManager gsm) {
		super(gsm);
	}

	@Override
	public void setup() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public void render() {
		// TODO Auto-generated method stub
	}

	@Override
	public void proccessInput() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

}
