package main.controller.assetManager;

/**
 *
 * This will be the top clasd that handles all the game resources
 *
 * INCLUDES:
 * 		> Serialization
 * 		> Deserialization
 * 		> Loading files
 * 		> Saving files
 *
 * If we have fonts sounds ect we will need to load them in. This will be what the program 
 * will speak to to achieve that...maybe not though...
 *
 *
 * @author <insert name>
 *
 */

public class AssetManager {

}
